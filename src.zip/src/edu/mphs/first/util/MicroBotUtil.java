/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.mphs.first.util;

/**
 *
 * @author marnold
 */
public class MicroBotUtil {

}
